#!/bin/bash
echo 'Stack squid-ecr Importing 0 of 47 ..'
../../scripts/060-get-s3.sh squid-ecr-accesslogss3-1hqy0o9c4mhch
echo 'Stack squid-ecr Importing 1 of 47 ..'
echo '#  AWS::EC2::VPCGatewayAttachment squid-Attac-E7IEEG96BUHA attached as part of IGW etc ..'
echo 'Stack squid-ecr Importing 2 of 47 ..'
../../scripts/625-get-code-build-project.sh squid-ecr-SquidProxyBuild
echo 'Stack squid-ecr Importing 3 of 47 ..'
../../scripts/050-get-iam-roles.sh squid-ecr-CodeBuildServiceRole-13V9IEE48IOCX
echo 'Stack squid-ecr Importing 4 of 47 ..'
../../scripts/050-get-iam-roles.sh squid-ecr-CodeCommitChangeEventRole-1P8MCPP7TNO11
echo 'Stack squid-ecr Importing 5 of 47 ..'
../../scripts/713-get-eb-rule.sh "squid-ecr-CodeCommitChangeEventRule-1GAJZHZAR2R5E"
echo 'Stack squid-ecr Importing 6 of 47 ..'
../../scripts/629-get-code-pipeline.sh squid-ecr-SquidProxy-CodeCommitEvents-pipeline
echo 'Stack squid-ecr Importing 7 of 47 ..'
../../scripts/060-get-s3.sh squid-ecr-codepipelineartifactstorebucket-3qgzkmb8mf0k
echo 'Stack squid-ecr Importing 8 of 47 ..'
echo '# AWS::S3::BucketPolicy squid-ecr-CodePipelineArtifactStoreBucketPolicy-KZWXASGMB6Z3 fetched as part of Bucket ..' 
echo 'Stack squid-ecr Importing 9 of 47 ..'
../../scripts/050-get-iam-roles.sh squid-ecr-CodePipelineServiceRole-1U9IRLT60MSM6
echo 'Stack squid-ecr Importing 10 of 47 ..'
../../scripts/get-ecr.sh squid-ecr-ecrrepository-czsjyev62gdh
echo 'Stack squid-ecr Importing 11 of 47 ..'
echo '# AWS::ApplicationAutoScaling::ScalableTarget squid-ecr-ECSCluster fetched as part of parent recources ' 
echo 'Stack squid-ecr Importing 12 of 47 ..'
../../scripts/350-get-ecs-cluster.sh squid-ecr-ECSCluster
echo 'Stack squid-ecr Importing 13 of 47 ..'
../../scripts/get-ecs-service.sh arn:aws:ecs:eu-west-1:666763910423:service/squid-ecr-ECSCluster/squid-ecr-ECSService-Kf9lgxSDQTcT
echo 'Stack squid-ecr Importing 14 of 47 ..'
echo '# AWS::ApplicationAutoScaling::ScalingPolicy ecs fetched as part of parent recources ' 
echo 'Stack squid-ecr Importing 15 of 47 ..'
../../scripts/elbv2-target-groups.sh arn:aws:elasticloadbalancing:eu-west-1:666763910423:targetgroup/squid-ecr-ECSTargetGroup/f7218ecccd33a618
echo 'Stack squid-ecr Importing 16 of 47 ..'
../../scripts/get-ecs-task.sh squid-ecr-ECSTaskDefinition-ywrFknOrKS3G:1
echo 'Stack squid-ecr Importing 17 of 47 ..'
../../scripts/050-get-iam-roles.sh squid-ecr-ECSTaskExecutionRole-BSNU23J2XF0S
echo 'Stack squid-ecr Importing 18 of 47 ..'
../../scripts/070-get-cw-log-grp.sh /squid-ecr-ECSTaskLogGroup-s2EMEBzWf9GA
echo 'Stack squid-ecr Importing 19 of 47 ..'
../../scripts/110-get-security-group.sh sg-0b7aada9480a491f5
echo 'Stack squid-ecr Importing 20 of 47 ..'
echo '# AWS::EC2::SecurityGroupIngress ECSTaskSecurityGroupSelfIngress fetched as part of SecurityGroup..'
echo 'Stack squid-ecr Importing 21 of 47 ..'
../../scripts/get-eip.sh 52.31.253.136
echo 'Stack squid-ecr Importing 22 of 47 ..'
../../scripts/get-eip.sh 54.228.147.200
echo 'Stack squid-ecr Importing 23 of 47 ..'
../../scripts/120-get-igw.sh igw-06bb834c9146068a8
echo 'Stack squid-ecr Importing 24 of 47 ..'
../../scripts/elbv2.sh arn:aws:elasticloadbalancing:eu-west-1:666763910423:loadbalancer/net/squid-e-NLB-1FYF3MKVQICGH/e2ffa582d8e58260
echo 'Stack squid-ecr Importing 25 of 47 ..'
echo '# AWS::S3::BucketPolicy squid-ecr-NLBAccessLogsBucketPolicy-1B69D0KSZGLI9 fetched as part of Bucket ..' 
echo 'Stack squid-ecr Importing 26 of 47 ..'
../../scripts/elbv2_listener.sh arn:aws:elasticloadbalancing:eu-west-1:666763910423:listener/net/squid-e-NLB-1FYF3MKVQICGH/e2ffa582d8e58260/d777e15652cac446
echo 'Stack squid-ecr Importing 27 of 47 ..'
../../scripts/140-get-route-table.sh rtb-00c2a3920ce34d43f
echo 'Stack squid-ecr Importing 28 of 47 ..'
echo '#  AWS::EC2::Route squid-Priva-N2ZRJIXL88VP  fetched as part of RouteTable..'
echo 'Stack squid-ecr Importing 29 of 47 ..'
../../scripts/140-get-route-table.sh rtb-067ca9457ae19f31d
echo 'Stack squid-ecr Importing 30 of 47 ..'
echo '#  AWS::EC2::Route squid-Priva-577HEQL8C3I6  fetched as part of RouteTable..'
echo 'Stack squid-ecr Importing 31 of 47 ..'
../../scripts/141-get-route-table-associations.sh rtbassoc-0df7dec1a7a9afbcd
echo 'Stack squid-ecr Importing 32 of 47 ..'
../../scripts/141-get-route-table-associations.sh rtbassoc-0e8a86d783bbbf848
echo 'Stack squid-ecr Importing 33 of 47 ..'
../../scripts/105-get-subnet.sh subnet-08aae867856e9c1ac
echo 'Stack squid-ecr Importing 34 of 47 ..'
../../scripts/105-get-subnet.sh subnet-0445458c15388c163
echo 'Stack squid-ecr Importing 35 of 47 ..'
../../scripts/130-get-natgw.sh nat-0ec7a73a5b7000d2d
echo 'Stack squid-ecr Importing 36 of 47 ..'
../../scripts/130-get-natgw.sh nat-036c508568ce804fc
echo 'Stack squid-ecr Importing 37 of 47 ..'
../../scripts/140-get-route-table.sh rtb-04df3b5a592773c27
echo 'Stack squid-ecr Importing 38 of 47 ..'
echo '#  AWS::EC2::Route squid-Publi-W8DOA0VAIKFF  fetched as part of RouteTable..'
echo 'Stack squid-ecr Importing 39 of 47 ..'
../../scripts/141-get-route-table-associations.sh rtbassoc-0b1e4cbf05fb6cbae
echo 'Stack squid-ecr Importing 40 of 47 ..'
../../scripts/141-get-route-table-associations.sh rtbassoc-07f3127e28c5a6de5
echo 'Stack squid-ecr Importing 41 of 47 ..'
../../scripts/105-get-subnet.sh subnet-06a1663084c09f60b
echo 'Stack squid-ecr Importing 42 of 47 ..'
../../scripts/105-get-subnet.sh subnet-00f1f3e65a0dfabf6
echo 'Stack squid-ecr Importing 43 of 47 ..'
../../scripts/100-get-vpc.sh vpc-090fcf5a7a3b94d20
echo 'Stack squid-ecr Importing 44 of 47 ..'
../../scripts/230-get-privatelink-config.sh vpce-svc-09041d05a3a2059cc
echo 'Stack squid-ecr Importing 45 of 47 ..'
../../scripts/162-get-vpc-flowlog.sh fl-0612bbc6bea876ca7
echo 'Stack squid-ecr Importing 46 of 47 ..'
../../scripts/070-get-cw-log-grp.sh /squid-ecr-VPCFlowLogGroup-86KjvUjzYCwZ
echo 'Stack squid-ecr Importing 47 of 47 ..'
../../scripts/050-get-iam-roles.sh squid-ecr-VPCFlowLogRoleRole-W155I2A4B2OL
echo "Commands Done .."
